module TypeProf
  VERSION = "0.21.1"
end
